
#include <iostream>
#include <cassert>

using namespace std;

//Definition of the node
template <class Type>
struct nodeType
{
	Type info;
	nodeType<Type> *next;
	nodeType<Type> *back;
};

template <class Type>
class doublyLinkedList
{
public:
	const doublyLinkedList<Type>& operator=(const doublyLinkedList<Type> &);  //Overload the assignment operator.
	void initializeList();       //Function to initialize the list to an empty state.
	bool isEmptyList() const;    //Function to determine whether the list is empty.
	void destroy();         //Function to delete all the nodes from the list.
	void print() const;      //Function to output the info contained in each node.
	void reversePrint() const;       //Function to output the info contained in each node in reverse order.
	int length() const;        //Function to return the number of nodes in the list.
	Type front() const;       //Function to return the first element of the list.
	Type back() const;        //Function to return the last element of the list.
	bool search(const Type& searchItem) const;   //Function to determine whether searchItem is in the list.
	void insert(const Type& insertItem);        //Function to insert insertItem in the list.
	void deleteNode(const Type& deleteItem);     //Function to delete deleteItem from the list.
	doublyLinkedList();         //default constructor
	doublyLinkedList(const doublyLinkedList<Type>& otherList);        //copy constructor
	~doublyLinkedList();        //destructor
	void beforeLastDelete();
	void insertFirst(const Type& insertItem );
	void insertLast(const Type& insertItem );
    Type deleteFirst();
    Type deleteLast();

protected:
	int count;
	nodeType<Type> *first; //pointer to the first node
	nodeType<Type> *last;  //pointer to the last node

private:
	void copyList(const doublyLinkedList<Type>& otherList);       //Function to make a copy of otherList.

};


template <class Type>
doublyLinkedList<Type>::doublyLinkedList()
{
	first = NULL;
	last = NULL;
	count = 0;
}

template <class Type>
bool doublyLinkedList<Type>::isEmptyList() const
{
	return (first == NULL);
}

template <class Type>
void doublyLinkedList<Type>::destroy()
{
	nodeType<Type>  *temp; //pointer to delete the node

	while (first != NULL)
	{
		temp = first;
		first = first->next;
		delete temp;
	}

	last = NULL;
	count = 0;
}

template <class Type>
void doublyLinkedList<Type>::initializeList()
{
	destroy();
}

template <class Type>
int doublyLinkedList<Type>::length() const
{
	return count;
}

template <class Type>
void doublyLinkedList<Type>::print() const
{
	nodeType<Type> *current; //pointer to traverse the list

	current = first;  //set current to point to the first node

	while (current != NULL)
	{
		cout << current->info << "  ";  //output info
		current = current->next;
	}//end while
}//end print


template <class Type>
void doublyLinkedList<Type>::reversePrint() const
{
	nodeType<Type> *current; //pointer to traverse
	//the list

	current = last;  //set current to point to the
	//last node

	while (current != NULL)
	{
		cout << current->info << "  ";
		current = current->back;
	}//end while
}//end reversePrint

template <class Type>
bool doublyLinkedList<Type>::search(const Type& searchItem) const
{
	bool found = false;
	nodeType<Type> *current; //pointer to traverse the list

	current = first;

	while (current != NULL && !found)
		if (current->info >= searchItem)
			found = true;
		else
			current = current->next;

	if (found)
		found = (current->info == searchItem); //test for
	//equality

	return found;
}//end search

template <class Type>
Type doublyLinkedList<Type>::front() const
{
	assert(first != NULL);

	return first->info;
}

template <class Type>
Type doublyLinkedList<Type>::back() const
{
	assert(last != NULL);

	return last->info;
}

template <class Type>
void doublyLinkedList<Type>::insert(const Type& insertItem)
{
	nodeType<Type> *current;      //pointer to traverse the list
	nodeType<Type> *trailCurrent =NULL; //pointer just before current
	nodeType<Type> *newNode;      //pointer to create a node
	bool found;

	newNode = new nodeType<Type>; //create the node
	newNode->info = insertItem;  //store the new item in the node
	newNode->next = NULL;
	newNode->back = NULL;

	if (first == NULL) //if the list is empty, newNode is
		//the only node
	{
		first = newNode;
		last = newNode;
		count++;
	}
	else
	{
		found = false;
		current = first;

		while (current != NULL && !found) //search the list
			if (current->info >= insertItem)
				found = true;
			else
			{
				trailCurrent = current;
				current = current->next;
			}

		if (current == first) //insert newNode before first
		{
			first->back = newNode;
			newNode->next = first;
			first = newNode;
			count++;
		}
		else
		{
			//insert newNode between trailCurrent and current
			if (current != NULL)
			{
				trailCurrent->next = newNode;
				newNode->back = trailCurrent;
				newNode->next = current;
				current->back = newNode;
			}
			else
			{
				trailCurrent->next = newNode;
				newNode->back = trailCurrent;
				last = newNode;
			}

			count++;
		}//end else
	}//end else
}//end insert

template <class Type>
void doublyLinkedList<Type>::deleteNode(const Type& deleteItem)
{
	nodeType<Type> *current; //pointer to traverse the list
	nodeType<Type> *trailCurrent; //pointer just before current

	bool found;

	if (first == NULL)
		cout << "Cannot delete from an empty list." << endl;
	else if (first->info == deleteItem) //node to be deleted is
		//the first node
	{
		current = first;
		first = first->next;

		if (first != NULL)
			first->back = NULL;
		else
			last = NULL;

		count--;

		delete current;
	}
	else
	{
		found = false;
		current = first;

		while (current != NULL && !found)  //search the list
			if (current->info >= deleteItem)
				found = true;
			else
				current = current->next;

		if (current == NULL)
			cout << "The item to be deleted is not in "
			<< "the list." << endl;
		else if (current->info == deleteItem) //check for
			//equality
		{
			trailCurrent = current->back;
			trailCurrent->next = current->next;

			if (current->next != NULL)
				current->next->back = trailCurrent;

			if (current == last)
				last = trailCurrent;

			count--;
			delete current;
		}
		else
			cout << "The item to be deleted is not in list."
			<< endl;
	}//end else
}//end deleteNode

template<class Type>
void doublyLinkedList<Type>::copyList(const doublyLinkedList<Type>& otherList)
{
	nodeType<Type> *newNode; //pointer to create a node
	nodeType<Type> *current; //pointer to traverse the list

	if (first != NULL) //if the list is nonempty, make it empty
		destroy();

	if (otherList.first == NULL) //otherList is empty
	{
		first = NULL;
		last = NULL;
		count = 0;
	}
	else
	{
		current = otherList.first;  //current points to the
		//list to be copied.
		count = otherList.count;

		//copy the first node
		first = new nodeType<Type>;  //create the node
		first->info = current->info;	//copy the info
		first->next = NULL;
		first->back = NULL;
		last = first;

		current = current->next;

		//copy the remaining list
		while (current != NULL)
		{
			newNode = new nodeType<Type>;  //create the node

			newNode->info = current->info;
			newNode->next = NULL;
			newNode->back = last;
			last->next = newNode;
			last = newNode;
			current = current->next;
		}//end while
	}//end else
}//end copyList

template<class Type>
doublyLinkedList<Type>::doublyLinkedList(const doublyLinkedList<Type>& otherList)
{
	first = NULL;
	copyList(otherList);
}

template<class Type>
const doublyLinkedList<Type>& doublyLinkedList<Type>::operator=
(const doublyLinkedList<Type>& otherList)
{
	if (this != &otherList) //avoid self-copy
	{
		copyList(otherList);
	}//end else

	return *this;
}

template<class Type>
doublyLinkedList<Type>::~doublyLinkedList()
{
	destroy();
}
template<class Type>
void doublyLinkedList<Type> ::beforeLastDelete() {

	nodeType<Type> *temp;

	while (last->back != NULL) {

		if (last->back == first || count == 2) {
			temp = first;
			first = last;
			delete temp;
			last->back = NULL;
			count--;


		}
		if (count  > 2) {
			temp = last->back->back;
			last->back = temp;
			temp = temp->next;
			delete temp;
			temp = last->back;
			temp->next = last;
			count--;
		}
	}

}





/***************** S T U D E N T    İ M P L E M E N T E D   M E T H O D S **********************/
template <class Type>
void doublyLinkedList<Type>::insertFirst(const Type& insterItem){

    nodeType<Type> *newNode;

    newNode = new nodeType<Type>;

    newNode->info = insterItem;
    newNode->back = NULL;
    newNode->next = NULL;
    if (isEmptyList()) //if the list is empty, newNode is
		//the only node
	{
		first = newNode;
		last = newNode;
		count++;
	}

    else{
        newNode->next = first;
        first->back = newNode;

        first = first->back;
    }



}

template <class Type>
void doublyLinkedList<Type>::insertLast(const Type& insertItem){

    nodeType<Type> *newNode;

    newNode = new nodeType<Type>;

    newNode->info = insertItem;

    newNode->back = NULL;

    newNode->next = NULL;



    if(isEmptyList()){

        first = newNode;
        last = newNode;
        count++;

    }

    else{

    newNode->back = last;

    last->next = newNode;

    last = last->next;

    count++;

    }


}
template <class Type>
Type doublyLinkedList<Type>::deleteFirst(){

    Type tempItem;

    if(isEmptyList()){

        cout << "List İs Already Empty";
        return -1;

    }

    if(count == 1){

        tempItem = first->info;
        destroy();
        return tempItem;

    }

    else{

        tempItem = first->info;
        first = first->next;
        delete first->back;
        count--;
        return tempItem;


    }

}

template <class Type>
Type doublyLinkedList<Type>::deleteLast(){

    Type tempItem;

    if(isEmptyList()){

        cout << "List İs Already Empty";
        return -1;

    }

    if(count == 1){

        tempItem = last->info;
        destroy();
        return tempItem;

    }

    else{

        tempItem = last->info;
        last = last->back;
        delete last->next;
        last->next = NULL;  //print fonksiyonu çalışırken bir soraki node'un NULL olup olmadığına baktığı için . . .
        count--;
        return tempItem;


    }

}

/***********************************************************************************************/

int main()
{

	doublyLinkedList<int> list1;

	int num,select;

	cout << "Please Select One Of The Option That below \n"<<"1::İnsertFirst  2::İnsertLast \n" <<endl;
	cin >>select;

	switch(select){


	case 1: cout << "Enter integers ending "
                 << "with -999" << endl;
            cin >> num;
            while (num != -999)
{

		list1.insertFirst(num);
		cin >> num;

	}
            break;
    case 2: cout << "Enter integers ending "
                 << "with -999" << endl;
            cin >> num;
            while (num != -999)
{

		list1.insertLast(num);
		cin >> num;

	}
            break;

    default: cout << "Unaccepted Number ! Default İnsertion selected(İnsert Last)" << endl;
             cin >> num;
             while(num != -999){
              list1.insertLast(num);
              cin >> num;
              }

}

	list1.print();

    num=list1.deleteLast();

    cout<<"\n\nDeleted From Last  ,  Item =" <<num<<endl;

   // num=list1.deleteFirst();      For Testing they surrounded with comment

   // cout<<"\n\nDeleted From First ,  Item =" <<num<<endl;

	cout <<"Last Status Of List" <<endl;

	list1.print();








	return 0;
}
